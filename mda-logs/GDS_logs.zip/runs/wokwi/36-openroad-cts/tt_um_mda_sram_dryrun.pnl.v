module tt_um_mda_sram_dryrun (clk,
    ena,
    rst_n,
    VPWR,
    VGND,
    ui_in,
    uio_in,
    uio_oe,
    uio_out,
    uo_out);
 input clk;
 input ena;
 input rst_n;
 inout VPWR;
 inout VGND;
 input [7:0] ui_in;
 input [7:0] uio_in;
 output [7:0] uio_oe;
 output [7:0] uio_out;
 output [7:0] uo_out;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire net82;
 wire net83;
 wire net84;
 wire net85;
 wire net86;
 wire net87;
 wire net88;
 wire net89;
 wire net90;
 wire net91;
 wire net92;
 wire net93;
 wire net94;
 wire net95;
 wire net96;
 wire net97;
 wire net98;
 wire net99;
 wire net100;
 wire net101;
 wire net102;
 wire net103;
 wire net104;
 wire net105;
 wire net106;
 wire clk_regs;
 wire net11;
 wire net12;
 wire net13;
 wire net14;
 wire net15;
 wire net16;
 wire net17;
 wire net18;
 wire net19;
 wire net20;
 wire net21;
 wire net22;
 wire net23;
 wire net24;
 wire net25;
 wire net26;
 wire net27;
 wire net28;
 wire net29;
 wire net30;
 wire net31;
 wire net32;
 wire net33;
 wire net34;
 wire net35;
 wire net36;
 wire net37;
 wire net38;
 wire net39;
 wire net40;
 wire net41;
 wire net42;
 wire net43;
 wire net44;
 wire net45;
 wire net46;
 wire net47;
 wire net48;
 wire net49;
 wire net50;
 wire net51;
 wire net52;
 wire net53;
 wire net54;
 wire net55;
 wire net56;
 wire net57;
 wire net58;
 wire net59;
 wire net60;
 wire net61;
 wire net62;
 wire net63;
 wire net64;
 wire done;
 wire \expected[0] ;
 wire \expected[13] ;
 wire \expected[14] ;
 wire \expected[15] ;
 wire fail;
 wire \mem_din[0] ;
 wire \mem_din[10] ;
 wire \mem_din[12] ;
 wire \mem_din[13] ;
 wire \mem_din[14] ;
 wire \mem_din[15] ;
 wire \mem_din[1] ;
 wire \mem_din[2] ;
 wire \mem_din[3] ;
 wire \mem_din[4] ;
 wire \mem_din[5] ;
 wire \mem_din[6] ;
 wire \mem_din[7] ;
 wire \mem_dout[0] ;
 wire \mem_dout[10] ;
 wire \mem_dout[11] ;
 wire \mem_dout[12] ;
 wire \mem_dout[13] ;
 wire \mem_dout[14] ;
 wire \mem_dout[15] ;
 wire \mem_dout[1] ;
 wire \mem_dout[2] ;
 wire \mem_dout[3] ;
 wire \mem_dout[4] ;
 wire \mem_dout[5] ;
 wire \mem_dout[6] ;
 wire \mem_dout[7] ;
 wire \mem_dout[8] ;
 wire \mem_dout[9] ;
 wire mem_en;
 wire mem_re;
 wire mem_we;
 wire pass;
 wire net1;
 wire \rst_pipe[0] ;
 wire \rst_pipe[1] ;
 wire \state[0] ;
 wire \state[3] ;
 wire \state[4] ;
 wire net65;
 wire net66;
 wire net67;
 wire net68;
 wire net69;
 wire net70;
 wire net71;
 wire net72;
 wire net73;
 wire net74;
 wire net75;
 wire net76;
 wire net77;
 wire net78;
 wire net79;
 wire net80;
 wire net81;
 wire net2;
 wire net3;
 wire net4;
 wire net5;
 wire net6;
 wire net7;
 wire net8;
 wire net9;
 wire net10;
 wire net;
 wire clknet_0_clk;
 wire clknet_1_0__leaf_clk;
 wire clknet_0_clk_regs;
 wire clknet_2_0__leaf_clk_regs;
 wire clknet_2_1__leaf_clk_regs;
 wire clknet_2_2__leaf_clk_regs;
 wire clknet_2_3__leaf_clk_regs;
 wire delaynet_0_clk;

 sg13cmos5l_inv_1 _135_ (.VDD(VPWR),
    .Y(_038_),
    .A(\mem_dout[3] ),
    .VSS(VGND));
 sg13cmos5l_inv_1 _136_ (.VDD(VPWR),
    .Y(_039_),
    .A(\mem_dout[2] ),
    .VSS(VGND));
 sg13cmos5l_inv_1 _137_ (.VDD(VPWR),
    .Y(_040_),
    .A(\mem_dout[1] ),
    .VSS(VGND));
 sg13cmos5l_inv_1 _138_ (.VDD(VPWR),
    .Y(_041_),
    .A(\mem_dout[0] ),
    .VSS(VGND));
 sg13cmos5l_inv_1 _139_ (.VDD(VPWR),
    .Y(_042_),
    .A(fail),
    .VSS(VGND));
 sg13cmos5l_inv_1 _140_ (.VDD(VPWR),
    .Y(_043_),
    .A(\expected[15] ),
    .VSS(VGND));
 sg13cmos5l_inv_1 _141_ (.VDD(VPWR),
    .Y(_044_),
    .A(\expected[14] ),
    .VSS(VGND));
 sg13cmos5l_inv_1 _142_ (.VDD(VPWR),
    .Y(_045_),
    .A(net2),
    .VSS(VGND));
 sg13cmos5l_inv_1 _143_ (.VDD(VPWR),
    .Y(\mem_din[10] ),
    .A(net7),
    .VSS(VGND));
 sg13cmos5l_and2_1 _144_ (.A(mem_re),
    .B(net2),
    .X(_000_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_or2_1 _145_ (.VSS(VGND),
    .VDD(VPWR),
    .X(mem_we),
    .B(net6),
    .A(\state[3] ));
 sg13cmos5l_or2_1 _146_ (.VSS(VGND),
    .VDD(VPWR),
    .X(mem_en),
    .B(mem_we),
    .A(mem_re));
 sg13cmos5l_nor2b_1 _147_ (.A(fail),
    .B_N(done),
    .Y(pass),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_nand4_1 _148_ (.B(\expected[14] ),
    .C(net9),
    .A(\expected[15] ),
    .Y(_046_),
    .VDD(VPWR),
    .VSS(VGND),
    .D(\expected[0] ));
 sg13cmos5l_and2_1 _149_ (.A(net2),
    .B(_046_),
    .X(_047_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_nor2_1 _150_ (.A(_045_),
    .B(_046_),
    .Y(_048_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_a22oi_1 _151_ (.Y(_049_),
    .B1(_048_),
    .B2(net6),
    .A2(_047_),
    .A1(\state[3] ),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_inv_1 _152_ (.VDD(VPWR),
    .Y(_004_),
    .A(_049_),
    .VSS(VGND));
 sg13cmos5l_a22oi_1 _153_ (.Y(_050_),
    .B1(_048_),
    .B2(\state[3] ),
    .A2(_047_),
    .A1(net4),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_inv_1 _154_ (.VDD(VPWR),
    .Y(_003_),
    .A(_050_),
    .VSS(VGND));
 sg13cmos5l_a22oi_1 _155_ (.Y(_051_),
    .B1(_048_),
    .B2(net4),
    .A2(done),
    .A1(net2),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_inv_1 _156_ (.VDD(VPWR),
    .Y(_002_),
    .A(_051_),
    .VSS(VGND));
 sg13cmos5l_a21oi_1 _157_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(net2),
    .A2(\mem_din[10] ),
    .Y(_001_),
    .B1(_048_));
 sg13cmos5l_or2_1 _158_ (.VSS(VGND),
    .VDD(VPWR),
    .X(\mem_din[0] ),
    .B(net6),
    .A(\expected[0] ));
 sg13cmos5l_nor2b_1 _159_ (.A(net6),
    .B_N(net9),
    .Y(\mem_din[1] ),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_nand2_1 _160_ (.Y(\mem_din[2] ),
    .A(_044_),
    .B(\mem_din[10] ),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_nor2_1 _161_ (.A(_043_),
    .B(net6),
    .Y(\mem_din[3] ),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_and2_1 _162_ (.A(\expected[0] ),
    .B(net6),
    .X(\mem_din[12] ),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_inv_1 _163_ (.VDD(VPWR),
    .Y(\mem_din[4] ),
    .A(\mem_din[12] ),
    .VSS(VGND));
 sg13cmos5l_nand2_1 _164_ (.Y(\mem_din[5] ),
    .A(net10),
    .B(net8),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_nand2_1 _165_ (.Y(\mem_din[14] ),
    .A(_044_),
    .B(net6),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_inv_1 _166_ (.VDD(VPWR),
    .Y(\mem_din[6] ),
    .A(\mem_din[14] ),
    .VSS(VGND));
 sg13cmos5l_nand2_1 _167_ (.Y(\mem_din[15] ),
    .A(_043_),
    .B(net8),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_inv_1 _168_ (.VDD(VPWR),
    .Y(\mem_din[7] ),
    .A(\mem_din[15] ),
    .VSS(VGND));
 sg13cmos5l_nand2b_1 _169_ (.Y(\mem_din[13] ),
    .B(net7),
    .A_N(net10),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_nor3_1 _170_ (.A(net4),
    .B(\state[3] ),
    .C(net6),
    .Y(_052_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_nor2b_1 _171_ (.A(\expected[0] ),
    .B_N(_052_),
    .Y(_053_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_nor2b_1 _172_ (.A(_052_),
    .B_N(\expected[0] ),
    .Y(_054_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_nor3_1 _173_ (.A(_045_),
    .B(_053_),
    .C(_054_),
    .Y(_005_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_o21ai_1 _174_ (.B1(net2),
    .VDD(VPWR),
    .Y(_014_),
    .VSS(VGND),
    .A1(net9),
    .A2(_054_));
 sg13cmos5l_a21oi_1 _175_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(net9),
    .A2(_054_),
    .Y(_006_),
    .B1(_014_));
 sg13cmos5l_a21oi_1 _176_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(net9),
    .A2(_054_),
    .Y(_015_),
    .B1(\expected[14] ));
 sg13cmos5l_nand3_1 _177_ (.B(net9),
    .C(_054_),
    .A(\expected[14] ),
    .Y(_016_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_nand2_1 _178_ (.Y(_017_),
    .A(net2),
    .B(_016_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_nor2_1 _179_ (.A(_015_),
    .B(_017_),
    .Y(_007_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_o21ai_1 _180_ (.B1(net2),
    .VDD(VPWR),
    .Y(_018_),
    .VSS(VGND),
    .A1(_046_),
    .A2(_052_));
 sg13cmos5l_a21oi_1 _181_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_043_),
    .A2(_016_),
    .Y(_008_),
    .B1(_018_));
 sg13cmos5l_a21o_1 _182_ (.A2(\mem_dout[14] ),
    .A1(\mem_dout[2] ),
    .B1(_044_),
    .X(_019_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_o21ai_1 _183_ (.B1(_044_),
    .VDD(VPWR),
    .Y(_020_),
    .VSS(VGND),
    .A1(\mem_dout[2] ),
    .A2(\mem_dout[14] ));
 sg13cmos5l_o21ai_1 _184_ (.B1(_040_),
    .VDD(VPWR),
    .Y(_021_),
    .VSS(VGND),
    .A1(net9),
    .A2(\mem_dout[13] ));
 sg13cmos5l_a21o_1 _185_ (.A2(\mem_dout[13] ),
    .A1(net9),
    .B1(_040_),
    .X(_022_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_nand4_1 _186_ (.B(_020_),
    .C(_021_),
    .A(_019_),
    .Y(_023_),
    .VDD(VPWR),
    .VSS(VGND),
    .D(_022_));
 sg13cmos5l_nand3_1 _187_ (.B(\expected[15] ),
    .C(\mem_dout[15] ),
    .A(\mem_dout[3] ),
    .Y(_024_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_or2_1 _188_ (.VSS(VGND),
    .VDD(VPWR),
    .X(_025_),
    .B(\expected[15] ),
    .A(\mem_dout[3] ));
 sg13cmos5l_o21ai_1 _189_ (.B1(_024_),
    .VDD(VPWR),
    .Y(_026_),
    .VSS(VGND),
    .A1(\mem_dout[15] ),
    .A2(_025_));
 sg13cmos5l_nor4_1 _190_ (.A(\mem_dout[7] ),
    .B(\mem_dout[6] ),
    .C(\mem_dout[10] ),
    .D(\mem_dout[8] ),
    .Y(_027_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_and4_1 _191_ (.A(\mem_dout[4] ),
    .B(\mem_dout[5] ),
    .C(\mem_dout[9] ),
    .D(\mem_dout[11] ),
    .X(_028_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_nor3_1 _192_ (.A(\mem_dout[0] ),
    .B(\expected[0] ),
    .C(\mem_dout[12] ),
    .Y(_029_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_nand3_1 _193_ (.B(\expected[0] ),
    .C(\mem_dout[12] ),
    .A(\mem_dout[0] ),
    .Y(_030_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_nand2b_1 _194_ (.Y(_031_),
    .B(_030_),
    .A_N(_029_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_nand4_1 _195_ (.B(_027_),
    .C(_028_),
    .A(_026_),
    .Y(_032_),
    .VDD(VPWR),
    .VSS(VGND),
    .D(_031_));
 sg13cmos5l_o21ai_1 _196_ (.B1(net4),
    .VDD(VPWR),
    .Y(_033_),
    .VSS(VGND),
    .A1(_023_),
    .A2(_032_));
 sg13cmos5l_a21oi_1 _197_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_042_),
    .A2(_033_),
    .Y(_009_),
    .B1(_045_));
 sg13cmos5l_o21ai_1 _198_ (.B1(net3),
    .VDD(VPWR),
    .Y(_034_),
    .VSS(VGND),
    .A1(net4),
    .A2(uo_out[4]));
 sg13cmos5l_a21oi_1 _199_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(net4),
    .A2(_041_),
    .Y(_010_),
    .B1(_034_));
 sg13cmos5l_o21ai_1 _200_ (.B1(net3),
    .VDD(VPWR),
    .Y(_035_),
    .VSS(VGND),
    .A1(net4),
    .A2(uo_out[5]));
 sg13cmos5l_a21oi_1 _201_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(net4),
    .A2(_040_),
    .Y(_011_),
    .B1(_035_));
 sg13cmos5l_o21ai_1 _202_ (.B1(net3),
    .VDD(VPWR),
    .Y(_036_),
    .VSS(VGND),
    .A1(net5),
    .A2(uo_out[6]));
 sg13cmos5l_a21oi_1 _203_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(net5),
    .A2(_039_),
    .Y(_012_),
    .B1(_036_));
 sg13cmos5l_o21ai_1 _204_ (.B1(net3),
    .VDD(VPWR),
    .Y(_037_),
    .VSS(VGND),
    .A1(uo_out[7]),
    .A2(net5));
 sg13cmos5l_a21oi_1 _205_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_038_),
    .A2(net5),
    .Y(_013_),
    .B1(_037_));
 sg13cmos5l_dfrbpq_1 _206_ (.RESET_B(net89),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_005_),
    .Q(\expected[0] ),
    .CLK(clknet_2_1__leaf_clk_regs));
 sg13cmos5l_tiehi _206__89 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net89));
 sg13cmos5l_dfrbpq_1 _207_ (.RESET_B(net87),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_006_),
    .Q(\expected[13] ),
    .CLK(clknet_2_1__leaf_clk_regs));
 sg13cmos5l_tiehi _207__87 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net87));
 sg13cmos5l_dfrbpq_1 _208_ (.RESET_B(net85),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_007_),
    .Q(\expected[14] ),
    .CLK(clknet_2_0__leaf_clk_regs));
 sg13cmos5l_tiehi _208__85 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net85));
 sg13cmos5l_dfrbpq_1 _209_ (.RESET_B(net81),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_008_),
    .Q(\expected[15] ),
    .CLK(clknet_2_1__leaf_clk_regs));
 sg13cmos5l_tiehi _209__81 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net81));
 sg13cmos5l_dfrbpq_1 _210_ (.RESET_B(net91),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_009_),
    .Q(fail),
    .CLK(clknet_2_2__leaf_clk_regs));
 sg13cmos5l_tiehi _210__91 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net91));
 sg13cmos5l_dfrbpq_1 _211_ (.RESET_B(net88),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_010_),
    .Q(uo_out[4]),
    .CLK(clknet_2_2__leaf_clk_regs));
 sg13cmos5l_tiehi _211__88 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net88));
 sg13cmos5l_dfrbpq_1 _212_ (.RESET_B(net84),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_011_),
    .Q(uo_out[5]),
    .CLK(clknet_2_2__leaf_clk_regs));
 sg13cmos5l_tiehi _212__84 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net84));
 sg13cmos5l_dfrbpq_1 _213_ (.RESET_B(net90),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_012_),
    .Q(uo_out[6]),
    .CLK(clknet_2_3__leaf_clk_regs));
 sg13cmos5l_tiehi _213__90 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net90));
 sg13cmos5l_dfrbpq_1 _214_ (.RESET_B(net94),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_013_),
    .Q(uo_out[7]),
    .CLK(clknet_2_2__leaf_clk_regs));
 sg13cmos5l_tiehi _214__94 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net94));
 sg13cmos5l_dfrbpq_1 _215_ (.RESET_B(net95),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_001_),
    .Q(\state[0] ),
    .CLK(clknet_2_1__leaf_clk_regs));
 sg13cmos5l_tiehi _215__95 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net95));
 sg13cmos5l_dfrbpq_1 _216_ (.RESET_B(net86),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_002_),
    .Q(done),
    .CLK(clknet_2_3__leaf_clk_regs));
 sg13cmos5l_tiehi _216__86 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net86));
 sg13cmos5l_dfrbpq_1 _217_ (.RESET_B(net92),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_003_),
    .Q(mem_re),
    .CLK(clknet_2_0__leaf_clk_regs));
 sg13cmos5l_tiehi _217__92 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net92));
 sg13cmos5l_dfrbpq_1 _218_ (.RESET_B(net82),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_004_),
    .Q(\state[3] ),
    .CLK(clknet_2_0__leaf_clk_regs));
 sg13cmos5l_tiehi _218__82 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net82));
 sg13cmos5l_dfrbpq_1 _219_ (.RESET_B(net83),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_000_),
    .Q(\state[4] ),
    .CLK(clknet_2_0__leaf_clk_regs));
 sg13cmos5l_tiehi _219__83 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net83));
 sg13cmos5l_dfrbpq_1 _220_ (.RESET_B(net1),
    .VSS(VGND),
    .VDD(VPWR),
    .D(net93),
    .Q(\rst_pipe[0] ),
    .CLK(clknet_2_3__leaf_clk_regs));
 sg13cmos5l_tiehi _220__93 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net93));
 sg13cmos5l_dfrbpq_1 _221_ (.RESET_B(net1),
    .VSS(VGND),
    .VDD(VPWR),
    .D(\rst_pipe[0] ),
    .Q(\rst_pipe[1] ),
    .CLK(clknet_2_3__leaf_clk_regs));
 sg13cmos5l_buf_1 _319_ (.A(done),
    .X(uo_out[0]),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_1 _320_ (.A(pass),
    .X(uo_out[1]),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_1 _321_ (.A(fail),
    .X(uo_out[2]),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_8 clkbuf_0_clk (.A(delaynet_0_clk),
    .X(clknet_0_clk),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_8 clkbuf_0_clk_regs (.A(clk_regs),
    .X(clknet_0_clk_regs),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_8 clkbuf_1_0__f_clk (.A(clknet_0_clk),
    .X(clknet_1_0__leaf_clk),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_8 clkbuf_2_0__f_clk_regs (.A(clknet_0_clk_regs),
    .X(clknet_2_0__leaf_clk_regs),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_8 clkbuf_2_1__f_clk_regs (.A(clknet_0_clk_regs),
    .X(clknet_2_1__leaf_clk_regs),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_8 clkbuf_2_2__f_clk_regs (.A(clknet_0_clk_regs),
    .X(clknet_2_2__leaf_clk_regs),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_8 clkbuf_2_3__f_clk_regs (.A(clknet_0_clk_regs),
    .X(clknet_2_3__leaf_clk_regs),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_8 clkbuf_regs_0_clk (.A(clk),
    .X(clk_regs),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_8 delaybuf_0_clk (.A(clk),
    .X(delaynet_0_clk),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_1 fanout10 (.A(\expected[13] ),
    .X(net10),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_1 fanout2 (.A(\rst_pipe[1] ),
    .X(net2),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_1 fanout3 (.A(\rst_pipe[1] ),
    .X(net3),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_1 fanout4 (.A(\state[4] ),
    .X(net4),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_1 fanout5 (.A(\state[4] ),
    .X(net5),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_1 fanout6 (.A(net8),
    .X(net6),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_1 fanout7 (.A(net8),
    .X(net7),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_1 fanout8 (.A(\state[0] ),
    .X(net8),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_1 fanout9 (.A(net10),
    .X(net9),
    .VDD(VPWR),
    .VSS(VGND));
 sg13cmos5l_buf_1 input1 (.A(rst_n),
    .X(net1),
    .VDD(VPWR),
    .VSS(VGND));
 RM_IHPSG13_1P_1024x16_c2_bm_bist sram (.\VSS! (VGND),
    .\VDD! (VPWR),
    .\VDDARRAY! (VPWR),
    .A_CLK(clknet_1_0__leaf_clk),
    .A_REN(mem_re),
    .A_WEN(mem_we),
    .A_MEN(mem_en),
    .A_DLY(net106),
    .A_BIST_EN(net59),
    .A_BIST_CLK(net42),
    .A_BIST_REN(net61),
    .A_BIST_WEN(net62),
    .A_BIST_MEN(net60),
    .A_ADDR({net15,
    net14,
    net13,
    net12,
    net11,
    net,
    \expected[15] ,
    \expected[14] ,
    net10,
    \expected[0] }),
    .A_BIST_ADDR({net25,
    net24,
    net23,
    net22,
    net21,
    net20,
    net19,
    net18,
    net17,
    net16}),
    .A_BIST_BM({net41,
    net40,
    net39,
    net38,
    net37,
    net36,
    net35,
    net34,
    net33,
    net32,
    net31,
    net30,
    net29,
    net28,
    net27,
    net26}),
    .A_BIST_DIN({net58,
    net57,
    net56,
    net55,
    net54,
    net53,
    net52,
    net51,
    net50,
    net49,
    net48,
    net47,
    net46,
    net45,
    net44,
    net43}),
    .A_BM({net8,
    net8,
    net7,
    net7,
    net7,
    net7,
    net7,
    net7,
    net103,
    net102,
    net101,
    net100,
    net99,
    net98,
    net97,
    net96}),
    .A_DIN({\mem_din[15] ,
    \mem_din[14] ,
    \mem_din[13] ,
    \mem_din[12] ,
    net105,
    \mem_din[10] ,
    net104,
    net63,
    \mem_din[7] ,
    \mem_din[6] ,
    \mem_din[5] ,
    \mem_din[4] ,
    \mem_din[3] ,
    \mem_din[2] ,
    \mem_din[1] ,
    \mem_din[0] }),
    .A_DOUT({\mem_dout[15] ,
    \mem_dout[14] ,
    \mem_dout[13] ,
    \mem_dout[12] ,
    \mem_dout[11] ,
    \mem_dout[10] ,
    \mem_dout[9] ,
    \mem_dout[8] ,
    \mem_dout[7] ,
    \mem_dout[6] ,
    \mem_dout[5] ,
    \mem_dout[4] ,
    \mem_dout[3] ,
    \mem_dout[2] ,
    \mem_dout[1] ,
    \mem_dout[0] }));
 sg13cmos5l_tiehi sram_100 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net100));
 sg13cmos5l_tiehi sram_101 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net101));
 sg13cmos5l_tiehi sram_102 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net102));
 sg13cmos5l_tiehi sram_103 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net103));
 sg13cmos5l_tiehi sram_104 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net104));
 sg13cmos5l_tiehi sram_105 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net105));
 sg13cmos5l_tiehi sram_106 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net106));
 sg13cmos5l_tielo sram_11 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net));
 sg13cmos5l_tielo sram_12 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net11));
 sg13cmos5l_tielo sram_13 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net12));
 sg13cmos5l_tielo sram_14 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net13));
 sg13cmos5l_tielo sram_15 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net14));
 sg13cmos5l_tielo sram_16 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net15));
 sg13cmos5l_tielo sram_17 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net16));
 sg13cmos5l_tielo sram_18 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net17));
 sg13cmos5l_tielo sram_19 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net18));
 sg13cmos5l_tielo sram_20 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net19));
 sg13cmos5l_tielo sram_21 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net20));
 sg13cmos5l_tielo sram_22 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net21));
 sg13cmos5l_tielo sram_23 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net22));
 sg13cmos5l_tielo sram_24 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net23));
 sg13cmos5l_tielo sram_25 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net24));
 sg13cmos5l_tielo sram_26 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net25));
 sg13cmos5l_tielo sram_27 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net26));
 sg13cmos5l_tielo sram_28 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net27));
 sg13cmos5l_tielo sram_29 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net28));
 sg13cmos5l_tielo sram_30 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net29));
 sg13cmos5l_tielo sram_31 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net30));
 sg13cmos5l_tielo sram_32 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net31));
 sg13cmos5l_tielo sram_33 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net32));
 sg13cmos5l_tielo sram_34 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net33));
 sg13cmos5l_tielo sram_35 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net34));
 sg13cmos5l_tielo sram_36 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net35));
 sg13cmos5l_tielo sram_37 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net36));
 sg13cmos5l_tielo sram_38 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net37));
 sg13cmos5l_tielo sram_39 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net38));
 sg13cmos5l_tielo sram_40 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net39));
 sg13cmos5l_tielo sram_41 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net40));
 sg13cmos5l_tielo sram_42 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net41));
 sg13cmos5l_tielo sram_43 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net42));
 sg13cmos5l_tielo sram_44 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net43));
 sg13cmos5l_tielo sram_45 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net44));
 sg13cmos5l_tielo sram_46 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net45));
 sg13cmos5l_tielo sram_47 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net46));
 sg13cmos5l_tielo sram_48 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net47));
 sg13cmos5l_tielo sram_49 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net48));
 sg13cmos5l_tielo sram_50 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net49));
 sg13cmos5l_tielo sram_51 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net50));
 sg13cmos5l_tielo sram_52 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net51));
 sg13cmos5l_tielo sram_53 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net52));
 sg13cmos5l_tielo sram_54 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net53));
 sg13cmos5l_tielo sram_55 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net54));
 sg13cmos5l_tielo sram_56 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net55));
 sg13cmos5l_tielo sram_57 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net56));
 sg13cmos5l_tielo sram_58 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net57));
 sg13cmos5l_tielo sram_59 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net58));
 sg13cmos5l_tielo sram_60 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net59));
 sg13cmos5l_tielo sram_61 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net60));
 sg13cmos5l_tielo sram_62 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net61));
 sg13cmos5l_tielo sram_63 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net62));
 sg13cmos5l_tielo sram_64 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net63));
 sg13cmos5l_tiehi sram_96 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net96));
 sg13cmos5l_tiehi sram_97 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net97));
 sg13cmos5l_tiehi sram_98 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net98));
 sg13cmos5l_tiehi sram_99 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net99));
 sg13cmos5l_tielo tt_um_mda_sram_dryrun (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net64));
 sg13cmos5l_tielo tt_um_mda_sram_dryrun_65 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net65));
 sg13cmos5l_tielo tt_um_mda_sram_dryrun_66 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net66));
 sg13cmos5l_tielo tt_um_mda_sram_dryrun_67 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net67));
 sg13cmos5l_tielo tt_um_mda_sram_dryrun_68 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net68));
 sg13cmos5l_tielo tt_um_mda_sram_dryrun_69 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net69));
 sg13cmos5l_tielo tt_um_mda_sram_dryrun_70 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net70));
 sg13cmos5l_tielo tt_um_mda_sram_dryrun_71 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net71));
 sg13cmos5l_tielo tt_um_mda_sram_dryrun_72 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net72));
 sg13cmos5l_tielo tt_um_mda_sram_dryrun_73 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net73));
 sg13cmos5l_tielo tt_um_mda_sram_dryrun_74 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net74));
 sg13cmos5l_tielo tt_um_mda_sram_dryrun_75 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net75));
 sg13cmos5l_tielo tt_um_mda_sram_dryrun_76 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net76));
 sg13cmos5l_tielo tt_um_mda_sram_dryrun_77 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net77));
 sg13cmos5l_tielo tt_um_mda_sram_dryrun_78 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net78));
 sg13cmos5l_tielo tt_um_mda_sram_dryrun_79 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net79));
 sg13cmos5l_tielo tt_um_mda_sram_dryrun_80 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net80));
 assign uio_oe[0] = net64;
 assign uio_oe[1] = net65;
 assign uio_oe[2] = net66;
 assign uio_oe[3] = net67;
 assign uio_oe[4] = net68;
 assign uio_oe[5] = net69;
 assign uio_oe[6] = net70;
 assign uio_oe[7] = net71;
 assign uio_out[0] = net72;
 assign uio_out[1] = net73;
 assign uio_out[2] = net74;
 assign uio_out[3] = net75;
 assign uio_out[4] = net76;
 assign uio_out[5] = net77;
 assign uio_out[6] = net78;
 assign uio_out[7] = net79;
 assign uo_out[3] = net80;
endmodule
