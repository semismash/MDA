module tt_um_mda_sram_dryrun (clk,
    ena,
    rst_n,
    ui_in,
    uio_in,
    uio_oe,
    uio_out,
    uo_out);
 input clk;
 input ena;
 input rst_n;
 input [7:0] ui_in;
 input [7:0] uio_in;
 output [7:0] uio_oe;
 output [7:0] uio_out;
 output [7:0] uo_out;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire _107_;
 wire _108_;
 wire _109_;
 wire _110_;
 wire _111_;
 wire _112_;
 wire _113_;
 wire _114_;
 wire _115_;
 wire _116_;
 wire _117_;
 wire _118_;
 wire _119_;
 wire _120_;
 wire _121_;
 wire _122_;
 wire _123_;
 wire _124_;
 wire _125_;
 wire _126_;
 wire _127_;
 wire _128_;
 wire _129_;
 wire _130_;
 wire _131_;
 wire _132_;
 wire _133_;
 wire _134_;
 wire done;
 wire \expected[0] ;
 wire \expected[13] ;
 wire \expected[14] ;
 wire \expected[15] ;
 wire fail;
 wire \mem_din[0] ;
 wire \mem_din[10] ;
 wire \mem_din[12] ;
 wire \mem_din[13] ;
 wire \mem_din[14] ;
 wire \mem_din[15] ;
 wire \mem_din[1] ;
 wire \mem_din[2] ;
 wire \mem_din[3] ;
 wire \mem_din[4] ;
 wire \mem_din[5] ;
 wire \mem_din[6] ;
 wire \mem_din[7] ;
 wire \mem_dout[0] ;
 wire \mem_dout[10] ;
 wire \mem_dout[11] ;
 wire \mem_dout[12] ;
 wire \mem_dout[13] ;
 wire \mem_dout[14] ;
 wire \mem_dout[15] ;
 wire \mem_dout[1] ;
 wire \mem_dout[2] ;
 wire \mem_dout[3] ;
 wire \mem_dout[4] ;
 wire \mem_dout[5] ;
 wire \mem_dout[6] ;
 wire \mem_dout[7] ;
 wire \mem_dout[8] ;
 wire \mem_dout[9] ;
 wire mem_en;
 wire mem_re;
 wire mem_we;
 wire pass;
 wire \rst_pipe[0] ;
 wire \rst_pipe[1] ;
 wire \state[0] ;
 wire \state[3] ;
 wire \state[4] ;

 sg13cmos5l_inv_1 _135_ (.Y(_038_),
    .A(\mem_dout[3] ));
 sg13cmos5l_inv_1 _136_ (.Y(_039_),
    .A(\mem_dout[2] ));
 sg13cmos5l_inv_1 _137_ (.Y(_040_),
    .A(\mem_dout[1] ));
 sg13cmos5l_inv_1 _138_ (.Y(_041_),
    .A(\mem_dout[0] ));
 sg13cmos5l_inv_1 _139_ (.Y(_042_),
    .A(fail));
 sg13cmos5l_inv_1 _140_ (.Y(_043_),
    .A(\expected[15] ));
 sg13cmos5l_inv_1 _141_ (.Y(_044_),
    .A(\expected[14] ));
 sg13cmos5l_inv_1 _142_ (.Y(_045_),
    .A(\rst_pipe[1] ));
 sg13cmos5l_inv_1 _143_ (.Y(\mem_din[10] ),
    .A(\state[0] ));
 sg13cmos5l_and2_1 _144_ (.A(mem_re),
    .B(\rst_pipe[1] ),
    .X(_000_));
 sg13cmos5l_or2_1 _145_ (.X(mem_we),
    .B(\state[0] ),
    .A(\state[3] ));
 sg13cmos5l_or2_1 _146_ (.X(mem_en),
    .B(mem_we),
    .A(mem_re));
 sg13cmos5l_nor2b_1 _147_ (.A(fail),
    .B_N(done),
    .Y(pass));
 sg13cmos5l_nand4_1 _148_ (.B(\expected[14] ),
    .C(\expected[13] ),
    .A(\expected[15] ),
    .Y(_046_),
    .D(\expected[0] ));
 sg13cmos5l_and2_1 _149_ (.A(\rst_pipe[1] ),
    .B(_046_),
    .X(_047_));
 sg13cmos5l_nor2_1 _150_ (.A(_045_),
    .B(_046_),
    .Y(_048_));
 sg13cmos5l_a22oi_1 _151_ (.Y(_049_),
    .B1(_048_),
    .B2(\state[0] ),
    .A2(_047_),
    .A1(\state[3] ));
 sg13cmos5l_inv_1 _152_ (.Y(_004_),
    .A(_049_));
 sg13cmos5l_a22oi_1 _153_ (.Y(_050_),
    .B1(_048_),
    .B2(\state[3] ),
    .A2(_047_),
    .A1(\state[4] ));
 sg13cmos5l_inv_1 _154_ (.Y(_003_),
    .A(_050_));
 sg13cmos5l_a22oi_1 _155_ (.Y(_051_),
    .B1(_048_),
    .B2(\state[4] ),
    .A2(done),
    .A1(\rst_pipe[1] ));
 sg13cmos5l_inv_1 _156_ (.Y(_002_),
    .A(_051_));
 sg13cmos5l_a21oi_1 _157_ (.A1(\rst_pipe[1] ),
    .A2(\mem_din[10] ),
    .Y(_001_),
    .B1(_048_));
 sg13cmos5l_or2_1 _158_ (.X(\mem_din[0] ),
    .B(\state[0] ),
    .A(\expected[0] ));
 sg13cmos5l_nor2b_1 _159_ (.A(\state[0] ),
    .B_N(\expected[13] ),
    .Y(\mem_din[1] ));
 sg13cmos5l_nand2_1 _160_ (.Y(\mem_din[2] ),
    .A(_044_),
    .B(\mem_din[10] ));
 sg13cmos5l_nor2_1 _161_ (.A(_043_),
    .B(\state[0] ),
    .Y(\mem_din[3] ));
 sg13cmos5l_and2_1 _162_ (.A(\expected[0] ),
    .B(\state[0] ),
    .X(\mem_din[12] ));
 sg13cmos5l_inv_1 _163_ (.Y(\mem_din[4] ),
    .A(\mem_din[12] ));
 sg13cmos5l_nand2_1 _164_ (.Y(\mem_din[5] ),
    .A(\expected[13] ),
    .B(\state[0] ));
 sg13cmos5l_nand2_1 _165_ (.Y(\mem_din[14] ),
    .A(_044_),
    .B(\state[0] ));
 sg13cmos5l_inv_1 _166_ (.Y(\mem_din[6] ),
    .A(\mem_din[14] ));
 sg13cmos5l_nand2_1 _167_ (.Y(\mem_din[15] ),
    .A(_043_),
    .B(\state[0] ));
 sg13cmos5l_inv_1 _168_ (.Y(\mem_din[7] ),
    .A(\mem_din[15] ));
 sg13cmos5l_nand2b_1 _169_ (.Y(\mem_din[13] ),
    .B(\state[0] ),
    .A_N(\expected[13] ));
 sg13cmos5l_nor3_1 _170_ (.A(\state[4] ),
    .B(\state[3] ),
    .C(\state[0] ),
    .Y(_052_));
 sg13cmos5l_nor2b_1 _171_ (.A(\expected[0] ),
    .B_N(_052_),
    .Y(_053_));
 sg13cmos5l_nor2b_1 _172_ (.A(_052_),
    .B_N(\expected[0] ),
    .Y(_054_));
 sg13cmos5l_nor3_1 _173_ (.A(_045_),
    .B(_053_),
    .C(_054_),
    .Y(_005_));
 sg13cmos5l_o21ai_1 _174_ (.B1(\rst_pipe[1] ),
    .Y(_014_),
    .A1(\expected[13] ),
    .A2(_054_));
 sg13cmos5l_a21oi_1 _175_ (.A1(\expected[13] ),
    .A2(_054_),
    .Y(_006_),
    .B1(_014_));
 sg13cmos5l_a21oi_1 _176_ (.A1(\expected[13] ),
    .A2(_054_),
    .Y(_015_),
    .B1(\expected[14] ));
 sg13cmos5l_nand3_1 _177_ (.B(\expected[13] ),
    .C(_054_),
    .A(\expected[14] ),
    .Y(_016_));
 sg13cmos5l_nand2_1 _178_ (.Y(_017_),
    .A(\rst_pipe[1] ),
    .B(_016_));
 sg13cmos5l_nor2_1 _179_ (.A(_015_),
    .B(_017_),
    .Y(_007_));
 sg13cmos5l_o21ai_1 _180_ (.B1(\rst_pipe[1] ),
    .Y(_018_),
    .A1(_046_),
    .A2(_052_));
 sg13cmos5l_a21oi_1 _181_ (.A1(_043_),
    .A2(_016_),
    .Y(_008_),
    .B1(_018_));
 sg13cmos5l_a21o_1 _182_ (.A2(\mem_dout[14] ),
    .A1(\mem_dout[2] ),
    .B1(_044_),
    .X(_019_));
 sg13cmos5l_o21ai_1 _183_ (.B1(_044_),
    .Y(_020_),
    .A1(\mem_dout[2] ),
    .A2(\mem_dout[14] ));
 sg13cmos5l_o21ai_1 _184_ (.B1(_040_),
    .Y(_021_),
    .A1(\expected[13] ),
    .A2(\mem_dout[13] ));
 sg13cmos5l_a21o_1 _185_ (.A2(\mem_dout[13] ),
    .A1(\expected[13] ),
    .B1(_040_),
    .X(_022_));
 sg13cmos5l_nand4_1 _186_ (.B(_020_),
    .C(_021_),
    .A(_019_),
    .Y(_023_),
    .D(_022_));
 sg13cmos5l_nand3_1 _187_ (.B(\expected[15] ),
    .C(\mem_dout[15] ),
    .A(\mem_dout[3] ),
    .Y(_024_));
 sg13cmos5l_or2_1 _188_ (.X(_025_),
    .B(\expected[15] ),
    .A(\mem_dout[3] ));
 sg13cmos5l_o21ai_1 _189_ (.B1(_024_),
    .Y(_026_),
    .A1(\mem_dout[15] ),
    .A2(_025_));
 sg13cmos5l_nor4_1 _190_ (.A(\mem_dout[7] ),
    .B(\mem_dout[6] ),
    .C(\mem_dout[10] ),
    .D(\mem_dout[8] ),
    .Y(_027_));
 sg13cmos5l_and4_1 _191_ (.A(\mem_dout[4] ),
    .B(\mem_dout[5] ),
    .C(\mem_dout[9] ),
    .D(\mem_dout[11] ),
    .X(_028_));
 sg13cmos5l_nor3_1 _192_ (.A(\mem_dout[0] ),
    .B(\expected[0] ),
    .C(\mem_dout[12] ),
    .Y(_029_));
 sg13cmos5l_nand3_1 _193_ (.B(\expected[0] ),
    .C(\mem_dout[12] ),
    .A(\mem_dout[0] ),
    .Y(_030_));
 sg13cmos5l_nand2b_1 _194_ (.Y(_031_),
    .B(_030_),
    .A_N(_029_));
 sg13cmos5l_nand4_1 _195_ (.B(_027_),
    .C(_028_),
    .A(_026_),
    .Y(_032_),
    .D(_031_));
 sg13cmos5l_o21ai_1 _196_ (.B1(\state[4] ),
    .Y(_033_),
    .A1(_023_),
    .A2(_032_));
 sg13cmos5l_a21oi_1 _197_ (.A1(_042_),
    .A2(_033_),
    .Y(_009_),
    .B1(_045_));
 sg13cmos5l_o21ai_1 _198_ (.B1(\rst_pipe[1] ),
    .Y(_034_),
    .A1(\state[4] ),
    .A2(uo_out[4]));
 sg13cmos5l_a21oi_1 _199_ (.A1(\state[4] ),
    .A2(_041_),
    .Y(_010_),
    .B1(_034_));
 sg13cmos5l_o21ai_1 _200_ (.B1(\rst_pipe[1] ),
    .Y(_035_),
    .A1(\state[4] ),
    .A2(uo_out[5]));
 sg13cmos5l_a21oi_1 _201_ (.A1(\state[4] ),
    .A2(_040_),
    .Y(_011_),
    .B1(_035_));
 sg13cmos5l_o21ai_1 _202_ (.B1(\rst_pipe[1] ),
    .Y(_036_),
    .A1(\state[4] ),
    .A2(uo_out[6]));
 sg13cmos5l_a21oi_1 _203_ (.A1(\state[4] ),
    .A2(_039_),
    .Y(_012_),
    .B1(_036_));
 sg13cmos5l_o21ai_1 _204_ (.B1(\rst_pipe[1] ),
    .Y(_037_),
    .A1(uo_out[7]),
    .A2(\state[4] ));
 sg13cmos5l_a21oi_1 _205_ (.A1(_038_),
    .A2(\state[4] ),
    .Y(_013_),
    .B1(_037_));
 sg13cmos5l_dfrbpq_1 _206_ (.RESET_B(_063_),
    .D(_005_),
    .Q(\expected[0] ),
    .CLK(clk));
 sg13cmos5l_dfrbpq_1 _207_ (.RESET_B(_061_),
    .D(_006_),
    .Q(\expected[13] ),
    .CLK(clk));
 sg13cmos5l_dfrbpq_1 _208_ (.RESET_B(_059_),
    .D(_007_),
    .Q(\expected[14] ),
    .CLK(clk));
 sg13cmos5l_dfrbpq_1 _209_ (.RESET_B(_055_),
    .D(_008_),
    .Q(\expected[15] ),
    .CLK(clk));
 sg13cmos5l_dfrbpq_1 _210_ (.RESET_B(_065_),
    .D(_009_),
    .Q(fail),
    .CLK(clk));
 sg13cmos5l_dfrbpq_1 _211_ (.RESET_B(_062_),
    .D(_010_),
    .Q(uo_out[4]),
    .CLK(clk));
 sg13cmos5l_dfrbpq_1 _212_ (.RESET_B(_058_),
    .D(_011_),
    .Q(uo_out[5]),
    .CLK(clk));
 sg13cmos5l_dfrbpq_1 _213_ (.RESET_B(_064_),
    .D(_012_),
    .Q(uo_out[6]),
    .CLK(clk));
 sg13cmos5l_dfrbpq_1 _214_ (.RESET_B(_068_),
    .D(_013_),
    .Q(uo_out[7]),
    .CLK(clk));
 sg13cmos5l_dfrbpq_1 _215_ (.RESET_B(_069_),
    .D(_001_),
    .Q(\state[0] ),
    .CLK(clk));
 sg13cmos5l_dfrbpq_1 _216_ (.RESET_B(_060_),
    .D(_002_),
    .Q(done),
    .CLK(clk));
 sg13cmos5l_dfrbpq_1 _217_ (.RESET_B(_066_),
    .D(_003_),
    .Q(mem_re),
    .CLK(clk));
 sg13cmos5l_dfrbpq_1 _218_ (.RESET_B(_056_),
    .D(_004_),
    .Q(\state[3] ),
    .CLK(clk));
 sg13cmos5l_dfrbpq_1 _219_ (.RESET_B(_057_),
    .D(_000_),
    .Q(\state[4] ),
    .CLK(clk));
 sg13cmos5l_dfrbpq_1 _220_ (.RESET_B(rst_n),
    .D(_067_),
    .Q(\rst_pipe[0] ),
    .CLK(clk));
 sg13cmos5l_dfrbpq_1 _221_ (.RESET_B(rst_n),
    .D(\rst_pipe[0] ),
    .Q(\rst_pipe[1] ),
    .CLK(clk));
 sg13cmos5l_tiehi _222_ (.L_HI(_055_));
 sg13cmos5l_tiehi _223_ (.L_HI(_056_));
 sg13cmos5l_tiehi _224_ (.L_HI(_057_));
 sg13cmos5l_tiehi _225_ (.L_HI(_058_));
 sg13cmos5l_tiehi _226_ (.L_HI(_059_));
 sg13cmos5l_tiehi _227_ (.L_HI(_060_));
 sg13cmos5l_tiehi _228_ (.L_HI(_061_));
 sg13cmos5l_tiehi _229_ (.L_HI(_062_));
 sg13cmos5l_tiehi _230_ (.L_HI(_063_));
 sg13cmos5l_tiehi _231_ (.L_HI(_064_));
 sg13cmos5l_tiehi _232_ (.L_HI(_065_));
 sg13cmos5l_tiehi _233_ (.L_HI(_066_));
 sg13cmos5l_tiehi _234_ (.L_HI(_067_));
 sg13cmos5l_tiehi _235_ (.L_HI(_068_));
 sg13cmos5l_tiehi _236_ (.L_HI(_069_));
 sg13cmos5l_tiehi _237_ (.L_HI(_070_));
 sg13cmos5l_tiehi _238_ (.L_HI(_071_));
 sg13cmos5l_tiehi _239_ (.L_HI(_072_));
 sg13cmos5l_tiehi _240_ (.L_HI(_073_));
 sg13cmos5l_tiehi _241_ (.L_HI(_074_));
 sg13cmos5l_tiehi _242_ (.L_HI(_075_));
 sg13cmos5l_tiehi _243_ (.L_HI(_076_));
 sg13cmos5l_tiehi _244_ (.L_HI(_077_));
 sg13cmos5l_tiehi _245_ (.L_HI(_078_));
 sg13cmos5l_tiehi _246_ (.L_HI(_079_));
 sg13cmos5l_tiehi _247_ (.L_HI(_080_));
 sg13cmos5l_tielo _248_ (.L_LO(_081_));
 sg13cmos5l_tielo _249_ (.L_LO(_082_));
 sg13cmos5l_tielo _250_ (.L_LO(_083_));
 sg13cmos5l_tielo _251_ (.L_LO(_084_));
 sg13cmos5l_tielo _252_ (.L_LO(_085_));
 sg13cmos5l_tielo _253_ (.L_LO(_086_));
 sg13cmos5l_tielo _254_ (.L_LO(_087_));
 sg13cmos5l_tielo _255_ (.L_LO(_088_));
 sg13cmos5l_tielo _256_ (.L_LO(_089_));
 sg13cmos5l_tielo _257_ (.L_LO(_090_));
 sg13cmos5l_tielo _258_ (.L_LO(_091_));
 sg13cmos5l_tielo _259_ (.L_LO(_092_));
 sg13cmos5l_tielo _260_ (.L_LO(_093_));
 sg13cmos5l_tielo _261_ (.L_LO(_094_));
 sg13cmos5l_tielo _262_ (.L_LO(_095_));
 sg13cmos5l_tielo _263_ (.L_LO(_096_));
 sg13cmos5l_tielo _264_ (.L_LO(_097_));
 sg13cmos5l_tielo _265_ (.L_LO(_098_));
 sg13cmos5l_tielo _266_ (.L_LO(_099_));
 sg13cmos5l_tielo _267_ (.L_LO(_100_));
 sg13cmos5l_tielo _268_ (.L_LO(_101_));
 sg13cmos5l_tielo _269_ (.L_LO(_102_));
 sg13cmos5l_tielo _270_ (.L_LO(_103_));
 sg13cmos5l_tielo _271_ (.L_LO(_104_));
 sg13cmos5l_tielo _272_ (.L_LO(_105_));
 sg13cmos5l_tielo _273_ (.L_LO(_106_));
 sg13cmos5l_tielo _274_ (.L_LO(_107_));
 sg13cmos5l_tielo _275_ (.L_LO(_108_));
 sg13cmos5l_tielo _276_ (.L_LO(_109_));
 sg13cmos5l_tielo _277_ (.L_LO(_110_));
 sg13cmos5l_tielo _278_ (.L_LO(_111_));
 sg13cmos5l_tielo _279_ (.L_LO(_112_));
 sg13cmos5l_tielo _280_ (.L_LO(_113_));
 sg13cmos5l_tielo _281_ (.L_LO(_114_));
 sg13cmos5l_tielo _282_ (.L_LO(_115_));
 sg13cmos5l_tielo _283_ (.L_LO(_116_));
 sg13cmos5l_tielo _284_ (.L_LO(_117_));
 sg13cmos5l_tielo _285_ (.L_LO(_118_));
 sg13cmos5l_tielo _286_ (.L_LO(_119_));
 sg13cmos5l_tielo _287_ (.L_LO(_120_));
 sg13cmos5l_tielo _288_ (.L_LO(_121_));
 sg13cmos5l_tielo _289_ (.L_LO(_122_));
 sg13cmos5l_tielo _290_ (.L_LO(_123_));
 sg13cmos5l_tielo _291_ (.L_LO(_124_));
 sg13cmos5l_tielo _292_ (.L_LO(_125_));
 sg13cmos5l_tielo _293_ (.L_LO(_126_));
 sg13cmos5l_tielo _294_ (.L_LO(_127_));
 sg13cmos5l_tielo _295_ (.L_LO(_128_));
 sg13cmos5l_tielo _296_ (.L_LO(_129_));
 sg13cmos5l_tielo _297_ (.L_LO(_130_));
 sg13cmos5l_tielo _298_ (.L_LO(_131_));
 sg13cmos5l_tielo _299_ (.L_LO(_132_));
 sg13cmos5l_tielo _300_ (.L_LO(_133_));
 sg13cmos5l_tielo _301_ (.L_LO(_134_));
 sg13cmos5l_tielo _302_ (.L_LO(uio_oe[0]));
 sg13cmos5l_tielo _303_ (.L_LO(uio_oe[1]));
 sg13cmos5l_tielo _304_ (.L_LO(uio_oe[2]));
 sg13cmos5l_tielo _305_ (.L_LO(uio_oe[3]));
 sg13cmos5l_tielo _306_ (.L_LO(uio_oe[4]));
 sg13cmos5l_tielo _307_ (.L_LO(uio_oe[5]));
 sg13cmos5l_tielo _308_ (.L_LO(uio_oe[6]));
 sg13cmos5l_tielo _309_ (.L_LO(uio_oe[7]));
 sg13cmos5l_tielo _310_ (.L_LO(uio_out[0]));
 sg13cmos5l_tielo _311_ (.L_LO(uio_out[1]));
 sg13cmos5l_tielo _312_ (.L_LO(uio_out[2]));
 sg13cmos5l_tielo _313_ (.L_LO(uio_out[3]));
 sg13cmos5l_tielo _314_ (.L_LO(uio_out[4]));
 sg13cmos5l_tielo _315_ (.L_LO(uio_out[5]));
 sg13cmos5l_tielo _316_ (.L_LO(uio_out[6]));
 sg13cmos5l_tielo _317_ (.L_LO(uio_out[7]));
 sg13cmos5l_tielo _318_ (.L_LO(uo_out[3]));
 sg13cmos5l_buf_1 _319_ (.A(done),
    .X(uo_out[0]));
 sg13cmos5l_buf_1 _320_ (.A(pass),
    .X(uo_out[1]));
 sg13cmos5l_buf_1 _321_ (.A(fail),
    .X(uo_out[2]));
 RM_IHPSG13_1P_1024x16_c2_bm_bist sram (.A_CLK(clk),
    .A_REN(mem_re),
    .A_WEN(mem_we),
    .A_MEN(mem_en),
    .A_DLY(_080_),
    .A_BIST_EN(_130_),
    .A_BIST_CLK(_113_),
    .A_BIST_REN(_132_),
    .A_BIST_WEN(_133_),
    .A_BIST_MEN(_131_),
    .A_ADDR({_086_,
    _085_,
    _084_,
    _083_,
    _082_,
    _081_,
    \expected[15] ,
    \expected[14] ,
    \expected[13] ,
    \expected[0] }),
    .A_BIST_ADDR({_096_,
    _095_,
    _094_,
    _093_,
    _092_,
    _091_,
    _090_,
    _089_,
    _088_,
    _087_}),
    .A_BIST_BM({_112_,
    _111_,
    _110_,
    _109_,
    _108_,
    _107_,
    _106_,
    _105_,
    _104_,
    _103_,
    _102_,
    _101_,
    _100_,
    _099_,
    _098_,
    _097_}),
    .A_BIST_DIN({_129_,
    _128_,
    _127_,
    _126_,
    _125_,
    _124_,
    _123_,
    _122_,
    _121_,
    _120_,
    _119_,
    _118_,
    _117_,
    _116_,
    _115_,
    _114_}),
    .A_BM({\state[0] ,
    \state[0] ,
    \state[0] ,
    \state[0] ,
    \state[0] ,
    \state[0] ,
    \state[0] ,
    \state[0] ,
    _077_,
    _076_,
    _075_,
    _074_,
    _073_,
    _072_,
    _071_,
    _070_}),
    .A_DIN({\mem_din[15] ,
    \mem_din[14] ,
    \mem_din[13] ,
    \mem_din[12] ,
    _079_,
    \mem_din[10] ,
    _078_,
    _134_,
    \mem_din[7] ,
    \mem_din[6] ,
    \mem_din[5] ,
    \mem_din[4] ,
    \mem_din[3] ,
    \mem_din[2] ,
    \mem_din[1] ,
    \mem_din[0] }),
    .A_DOUT({\mem_dout[15] ,
    \mem_dout[14] ,
    \mem_dout[13] ,
    \mem_dout[12] ,
    \mem_dout[11] ,
    \mem_dout[10] ,
    \mem_dout[9] ,
    \mem_dout[8] ,
    \mem_dout[7] ,
    \mem_dout[6] ,
    \mem_dout[5] ,
    \mem_dout[4] ,
    \mem_dout[3] ,
    \mem_dout[2] ,
    \mem_dout[1] ,
    \mem_dout[0] }));
endmodule
